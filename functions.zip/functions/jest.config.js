module.exports = async () => {
  return {
    testTimeout: 60000
  };
};