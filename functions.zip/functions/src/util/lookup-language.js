class LookupLanguage {
  static ENGLISH = "en";
}

module.exports = {LookupLanguage}