class MimeTypes {
  static IMAGE_JPEG = "image/jpeg";
  static JSON = "application/json";

}

module.exports = {MimeTypes};